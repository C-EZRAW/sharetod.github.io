# Change Log

## [0.1.1] - 2015-12-03
- **Added** themeing styles

## [0.1.0] - 2015-12-01
- **Added** base styles and jekyll files
